package eu.dirk.haase.jdbc.pool.util;

public class MyKey {

    @Override
    public boolean equals(Object o) {
        return true;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
